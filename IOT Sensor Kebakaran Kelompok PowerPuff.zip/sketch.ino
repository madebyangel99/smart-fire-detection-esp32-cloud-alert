#define BUTTON_PIN 12   // Simulasi flame sensor
#define BUZZER_PIN 14
#define SMOKE_PIN 34    // Simulasi sensor asap (ADC)
#define LED_PIN 26

// Batas asap disesuaikan untuk skala ESP32 (0-4095)
int smokeThreshold = 1600; 

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  Serial.begin(115200); // Baud rate standar ESP32
}

void loop() {
  int api = digitalRead(BUTTON_PIN); // LOW = tombol ditekan
  int asap = analogRead(SMOKE_PIN);

  Serial.print("Api: ");
  Serial.print(api);
  Serial.print(" | Asap: ");
  Serial.println(asap);

  if (api == LOW || asap > smokeThreshold) {
    tone(BUZZER_PIN, 1000); // Bunyi alarm
    digitalWrite(LED_PIN, HIGH);
  } else {
    noTone(BUZZER_PIN);
    digitalWrite(LED_PIN, LOW);
  }

  delay(300);
}